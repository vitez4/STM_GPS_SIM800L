/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdbool.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
TIM_HandleTypeDef htim2;

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart5;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_UART4_Init(void);
static void MX_UART5_Init(void);
static void MX_TIM2_Init(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
uint8_t gps_rx_data = 0;
uint8_t gps_rx_buffer[1460] = {0};
uint16_t gps_rx_index = 0;

uint8_t rx_data = 0;
uint8_t rx_buffer[1460] = {0};
uint16_t rx_index = 0;

// GPS data
float gps_latitude = 0.0;
float gps_longitude = 0.0;
float gps_speed = 0.0;
float gps_course = 0.0;
int gps_date_day = 0;
int gps_date_month = 0;
int gps_date_year = 0;
int gps_time_hours = 0;
int gps_time_minutes = 0;
int gps_time_seconds = 0;

void setLock(bool lock)
{
    if (lock)
    {
        HAL_GPIO_WritePin(LOCK_GPIO_Port, LOCK_Pin, GPIO_PIN_SET);
    }
    else
    {
        HAL_GPIO_WritePin(LOCK_GPIO_Port, LOCK_Pin, GPIO_PIN_RESET);
    }
}

char* getLockStatus(void)
{
    if (HAL_GPIO_ReadPin(LOCK_GPIO_Port, LOCK_Pin))
    {
        return "Locked";
    }
    else
    {
        return "Unlocked";
    }
}

void setBuzzer(bool buzzer)
{
    if (buzzer)
    {
        HAL_TIM_PWM_Start(&htim2, TIM_CHANNEL_3);
    }
    else
    {
        HAL_TIM_PWM_Stop(&htim2, TIM_CHANNEL_3);
    }
    htim2.Instance->CCR3 = 100;
}

/**
 * Send AT command to SIM800 over UART.
 * @param command the command to be used the send AT command
 * @param delay to be used to the set pause to the reply
 * @return error, 0 is OK
 */
int SIM800_SendCommand(char *command, uint16_t delay)
{
    HAL_UART_Transmit_IT(&huart4, (unsigned char *)command, (uint16_t)strlen(command));

    HAL_Delay(delay);

    return 0;
}

void SIM800_Init()
{
	// Set the SIM800 to text mode
	SIM800_SendCommand("AT+CMGF=1\r\n", 1000);
}

void sendNotificationSMS()
{
    // Send an SMS notification
    char* data1 = "AT+CMGF=1\r\n";
    char* data2 = "AT+CMGS=\"+385997535886\"\r\n";

    // Send the GPS data along with the lock status
    char data3[256];
    sprintf(data3, "Latitude: %f, Longitude: %f, Speed: %f, Course: %f, Date: %d/%d/%d, Time: %d:%d:%d, Lock: %s",
            gps_latitude, gps_longitude, gps_speed, gps_course, gps_date_day, gps_date_month, gps_date_year, gps_time_hours, gps_time_minutes, gps_time_seconds, getLockStatus());

    char* data4 = 0x1A;

    SIM800_SendCommand(data1, 200);
    SIM800_SendCommand(data2, 200);
    SIM800_SendCommand(data3, 1000);
    SIM800_SendCommand(&data4, 2000);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {
    if (huart == &huart5) {
    	GPS_RxCallBack();
    } else if (huart == &huart4) {
        Sim800_RxCallBack();
    }
}

void clearSIMRxBuffer(void)
{
    rx_index = 0;
    memset(rx_buffer, 0, sizeof(rx_buffer));
}

void clearGPSRxBuffer(void)
{
    gps_rx_index = 0;
    memset(gps_rx_buffer, 0, sizeof(gps_rx_buffer));
}

void GPS_RxCallBack(void)
{
    // Parse the NMEA sentence - we're receiving a byte at a time
    // so we need to check if we've received a full sentence yet by checking for the \r\n at the end - only then do we clear the buffer
    gps_rx_buffer[gps_rx_index++] = gps_rx_data;
    if (gps_rx_index >= 2 && gps_rx_buffer[gps_rx_index - 2] == '\r' && gps_rx_buffer[gps_rx_index - 1] == '\n')
    {
        // We've received a full sentence, so check what it was
        if (strstr(gps_rx_buffer, "$GPRMC") != NULL)
        {
            // This is the format: $GPRMC,HHMMSS.SS,A,llll.ll,a,yyyyy.yy,a,x.x,x.x,ddmmyy,x.x,a*hh
            // With the following fields:
            // 1. UTC time
            // 2. Status, V = Navigation receiver warning, A = Data valid
            // 3. Latitude
            // 4. N or S
            // 5. Longitude
            // 6. E or W
            // 7. Speed over ground, knots
            // 8. Track made good, degrees true
            // 9. Date, ddmmyy
            // 10. Magnetic variation, degrees
            // 11. E or W
            // 12. Checksum

            // Parse the GPS data
            char *p = strtok(gps_rx_buffer, ",");
            int i = 0;
            while (p != NULL)
            {
                switch (i)
                {
                case 1:
                    // UTC time
                    gps_time_hours = (p[0] - '0') * 10 + (p[1] - '0');
                    gps_time_minutes = (p[2] - '0') * 10 + (p[3] - '0');
                    gps_time_seconds = (p[4] - '0') * 10 + (p[5] - '0');
                    break;
                case 3:
                    // Latitude
                    gps_latitude = (p[0] - '0') * 10 + (p[1] - '0');
                    gps_latitude += ((p[2] - '0') * 10 + (p[3] - '0')) / 60.0;
                    gps_latitude += ((p[5] - '0') * 10 + (p[6] - '0')) / 6000.0;
                    break;
                case 4:
                    // N or S
                    if (p[0] == 'S')
                    {
                        gps_latitude = -gps_latitude;
                    }
                    break;
                case 5:
                    // Longitude
                    gps_longitude = (p[0] - '0') * 100 + (p[1] - '0') * 10 + (p[2] - '0');
                    gps_longitude += ((p[3] - '0') * 10 + (p[4] - '0')) / 60.0;
                    gps_longitude += ((p[6] - '0') * 10 + (p[7] - '0')) / 6000.0;
                    break;
                case 6:
                    // E or W
                    if (p[0] == 'W')
                    {
                        gps_longitude = -gps_longitude;
                    }
                    break;
                case 7:
                    // Speed over ground, knots
                    gps_speed = (p[0] - '0') * 10 + (p[1] - '0');
                    gps_speed += ((p[2] - '0') * 10 + (p[3] - '0')) / 10.0;
                    break;
                case 8:
                    // Track made good, degrees true
                    gps_course = (
                        (p[0] - '0') * 100 +
                        (p[1] - '0') * 10 +
                        (p[2] - '0') +
                        (p[3] - '0') / 10.0 +
                        (p[4] - '0') / 100.0
                    );
                    break;
                case 9:
                    // Date, ddmmyy - ex. 210307 -> 21.03.2007
                    // While keeping in mind that the data is in a string but the values are numbers and will be saved as integers
                    gps_date_day = (p[0] - '0') * 10 + (p[1] - '0');
                    gps_date_month = (p[2] - '0') * 10 + (p[3] - '0');
                    gps_date_year = (p[4] - '0') * 10 + (p[5] - '0');

                    break;
                }

                // Get the next token
                p = strtok(NULL, ",");
                i++;

                // Check if we've parsed all the data we need
                if (i > 9)
                {
                    break;
                }
            }
        }

        // Clear the buffer
        clearGPSRxBuffer();
    }

    HAL_UART_Receive_IT(&huart5, &gps_rx_data, 1);
}

void Sim800_RxCallBack(void)
{
    // Parse the SIM800 response - we're receiving a byte at a time
    // so we need to check if we've received a full response yet by checking for the \r\n at the end - only then do we clear the buffer
    rx_buffer[rx_index++] = rx_data;
    if (rx_index >= 2 && rx_buffer[rx_index - 2] == '\r' && rx_buffer[rx_index - 1] == '\n')
    {
        // We've received a full response, so check what it was
        if (strstr(rx_buffer, "+CMTI:") != NULL)
        {
            // Parse the SMS index
            char *p = strstr(rx_buffer, ",");
            if (p != NULL)
            {
                int index = atoi(p + 1);

                // Read the SMS - we need to send the AT command AT+CMGR=<index>
                char command[32];
                sprintf(command, "AT+CMGR=%d\r\n", index);
                SIM800_SendCommand(command, 1000);
            }
        }
        else if (strstr(rx_buffer, "+CMGR:") != NULL)
        {
            // Parse the SMS content
            char *p = strstr(rx_buffer, "\r\n");
            if (p != NULL)
            {
                // Parse the content
                char *content = strstr(p + 2, "\r\n");

                // Check if the content is "Alarm", "Status", "Lock" or "Unlock"
                if (content != NULL)
                {
                    if (strstr(content, "Alarm") != NULL)
                    {
                        // Alarm - turn on the buzzer
                        setBuzzer(true);
                    }
                    else if (strstr(content, "Status") != NULL)
                    {
                        // Status - send SMS back with the current location, time and lock status
                        sendNotificationSMS();
                    }
                    else if (strstr(content, "Lock") != NULL)
                    {
                        setLock(true);
                    }
                    else if (strstr(content, "Unlock") != NULL)
                    {
                        setLock(false);
                        setBuzzer(false);
                    }
                }
            }
        }

        // Clear the buffer
        clearSIMRxBuffer();
    }
    HAL_UART_Receive_IT(&huart4, &rx_data, 1);

}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_UART4_Init();
  MX_UART5_Init();
  MX_TIM2_Init();
  /* USER CODE BEGIN 2 */

  // Initialize the SIM800
  SIM800_Init();

  HAL_UART_Receive_IT(&huart5, &gps_rx_data, 1);
  HAL_UART_Receive_IT(&huart4, &rx_data, 1);

  setLock(false);

  // Initialize the buzzer
  setBuzzer(false);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  if (!HAL_GPIO_ReadPin(B1_GPIO_Port, B1_Pin)) {
		  setLock(true);
	  }
	  HAL_Delay(500);
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE3);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 16;
  RCC_OscInitStruct.PLL.PLLN = 336;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV4;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief TIM2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM2_Init(void)
{

  /* USER CODE BEGIN TIM2_Init 0 */

  /* USER CODE END TIM2_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};
  TIM_OC_InitTypeDef sConfigOC = {0};

  /* USER CODE BEGIN TIM2_Init 1 */

  /* USER CODE END TIM2_Init 1 */
  htim2.Instance = TIM2;
  htim2.Init.Prescaler = 692-1;
  htim2.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim2.Init.Period = 500-1;
  htim2.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim2.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_PWM_Init(&htim2) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim2, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sConfigOC.OCMode = TIM_OCMODE_PWM1;
  sConfigOC.Pulse = 0;
  sConfigOC.OCPolarity = TIM_OCPOLARITY_HIGH;
  sConfigOC.OCFastMode = TIM_OCFAST_DISABLE;
  if (HAL_TIM_PWM_ConfigChannel(&htim2, &sConfigOC, TIM_CHANNEL_3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM2_Init 2 */

  /* USER CODE END TIM2_Init 2 */
  HAL_TIM_MspPostInit(&htim2);

}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 9600;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief UART5 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART5_Init(void)
{

  /* USER CODE BEGIN UART5_Init 0 */

  /* USER CODE END UART5_Init 0 */

  /* USER CODE BEGIN UART5_Init 1 */

  /* USER CODE END UART5_Init 1 */
  huart5.Instance = UART5;
  huart5.Init.BaudRate = 9600;
  huart5.Init.WordLength = UART_WORDLENGTH_8B;
  huart5.Init.StopBits = UART_STOPBITS_1;
  huart5.Init.Parity = UART_PARITY_NONE;
  huart5.Init.Mode = UART_MODE_TX_RX;
  huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart5.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart5) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART5_Init 2 */

  /* USER CODE END UART5_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
/* USER CODE BEGIN MX_GPIO_Init_1 */
/* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, LD2_Pin|LOCK_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LD2_Pin */
  GPIO_InitStruct.Pin = LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LD2_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : SIM_Interrupt_Pin */
  GPIO_InitStruct.Pin = SIM_Interrupt_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_FALLING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(SIM_Interrupt_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pin : LOCK_Pin */
  GPIO_InitStruct.Pin = LOCK_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_PULLDOWN;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LOCK_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI9_5_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI9_5_IRQn);

/* USER CODE BEGIN MX_GPIO_Init_2 */
/* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */


